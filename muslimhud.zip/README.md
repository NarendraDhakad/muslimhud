# angular2-social-app
Social app on ionic2(angular 2)
<br>
Screenshot
<br>
<img src="http://103.53.43.138/portfolio/socialapp.png" width="200">

A social app based on ionic2, angular 2
